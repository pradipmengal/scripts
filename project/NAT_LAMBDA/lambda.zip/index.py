import boto3, json

ec2 = boto3.client("ec2")

def find_eni_for_az(az):
    nis = ec2.describe_network_interfaces(Filters=[{"Name":"tag:Name","Values":[f"nat-eni-{az}"]}])["NetworkInterfaces"]
    return nis[0] if nis else None

def handler(event, context):
    print("event:", json.dumps(event))
    for rec in event.get("Records", []):
        msg = json.loads(rec.get("Sns", {}).get("Message", "{}")) if "Sns" in rec else json.loads(rec.get("body", "{}"))
        detail = msg.get("detail", {}) if "detail" in msg else msg
        asg = detail.get("AutoScalingGroupName") or msg.get("AutoScalingGroupName")
        lifecycle = detail.get("LifecycleTransition") or msg.get("LifecycleTransition")
        instance_id = detail.get("EC2InstanceId") or msg.get("EC2InstanceId")
        if not instance_id:
            continue
        inst = ec2.describe_instances(InstanceIds=[instance_id])["Reservations"][0]["Instances"][0]
        az = inst["Placement"]["AvailabilityZone"]
        eni = find_eni_for_az(az)
        if not eni:
            print("No ENI found for", az)
            continue
        eni_id = eni["NetworkInterfaceId"]
        try:
            ec2.modify_instance_attribute(InstanceId=instance_id, SourceDestCheck={"Value": False})
        except Exception as e:
            print("modify_instance_attribute err", e)
        if "LAUNCHING" in lifecycle:
            attach = eni.get("Attachment")
            if attach:
                try:
                    ec2.detach_network_interface(AttachmentId=attach["AttachmentId"], Force=True)
                except Exception as e:
                    print("detach err", e)
            try:
                ec2.attach_network_interface(NetworkInterfaceId=eni_id, InstanceId=instance_id, DeviceIndex=1)
                print("attached", eni_id, "to", instance_id)
            except Exception as e:
                print("attach err", e)
        elif "TERMINATING" in lifecycle:
            for iface in inst.get("NetworkInterfaces", []):
                if iface["NetworkInterfaceId"] == eni_id and "Attachment" in iface:
                    try:
                        ec2.detach_network_interface(AttachmentId=iface["Attachment"]["AttachmentId"], Force=True)
                    except Exception as e:
                        print("detach-on-term err", e)
    return {"ok": True}
